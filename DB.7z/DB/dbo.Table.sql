﻿CREATE TABLE [dbo].[Table]
(
	[Id] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [CountryName] NVARCHAR(MAX) NULL
)
